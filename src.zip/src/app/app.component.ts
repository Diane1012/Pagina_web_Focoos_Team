import { Component } from '@angular/core';
// Initialization for ES Users
import {
  Tab,
  initTE,
} from "tw-elements";

initTE({ Tab });

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'prueba_enlace';
}
